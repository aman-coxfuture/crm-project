const express = require("express");
const path = require("path");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const cookieParser = require("cookie-parser");
const fs = require("fs");

const authRoutes = require("./routes/authRoutes");
const tenantRoutes = require("./routes/tenantRoutes");
const userRoutes = require("./routes/userRoutes");
const schoolRoutes = require("./routes/schoolRoutes");
const facultyRoutes = require("./routes/facultyRoutes");
const studentRoutes = require("./routes/studentRoutes");
const classRoutes = require("./routes/classRoutes");
const assignmentRoutes = require("./routes/assignmentRoutes");
const staffRoutes = require("./routes/staffRoutes");
const attendanceRoutes = require("./routes/attendanceRoutes");
const facultyAttendanceRoutes = require("./routes/facultyAttendanceRoutes");
const staffAttendanceRoutes = require("./routes/staffAttendanceRoutes");
const timetableRoutes = require("./routes/timetableRoutes");
const examRoutes = require("./routes/examRoutes");
const examMarkRoutes = require("./routes/examMarkRoutes");
const feeRoutes = require("./routes/feeRoutes");
const feePaymentRoutes = require("./routes/feePaymentRoutes");
const feeSettingRoutes = require("./routes/feeSettingRoutes");
const academicSessionRoutes = require("./routes/academicSessionRoutes");
const staffFeeRoutes = require("./routes/staffFeeRoutes");
const salarySlipRoutes = require("./routes/salarySlipRoutes");
const studentAttendanceRoutes = require("./routes/studentAttendanceRoutes");
const leaveRoutes = require("./routes/leaveRoutes");
const courseworkAssignmentRoutes = require("./routes/courseworkAssignmentRoutes");
const noticeRoutes = require("./routes/noticeRoutes");
const app = express();

app.use(helmet());
app.use(cors());
app.use(morgan("dev"));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.get("/api/health", (req, res) => {
  res.status(200).json({
    success: true,
    message: "CRM API is running",
  });
});

app.use("/api/auth", authRoutes);
app.use("/api/tenants", tenantRoutes);
app.use("/api/users", userRoutes);
app.use("/api/school", schoolRoutes);
app.use("/api/faculty", facultyRoutes);
app.use("/api/students", studentRoutes);
app.use("/api/classes", classRoutes);
app.use("/api/assignments", assignmentRoutes);
app.use("/api/staff", staffRoutes);
app.use("/api/attendance", attendanceRoutes);
app.use("/api/faculty-attendance", facultyAttendanceRoutes);
app.use("/api/staff-attendance", staffAttendanceRoutes);
app.use("/api/timetable", timetableRoutes);
app.use("/api/exams", examRoutes);
app.use("/api/exam-marks", examMarkRoutes);
app.use("/api/fees", feeRoutes);
app.use("/api/fee-payments", feePaymentRoutes);
app.use("/api/fee-settings", feeSettingRoutes);
app.use("/api/academic-sessions", academicSessionRoutes);
app.use("/api/staff-fees", staffFeeRoutes);
app.use("/api/salary-slips", salarySlipRoutes);
app.use("/api/student-attendance", studentAttendanceRoutes);
app.use("/api/leaves", leaveRoutes);
app.use("/api/coursework-assignments", courseworkAssignmentRoutes);
app.use("/api/notices", noticeRoutes);
app.get("/api/uploads/assignments/:filename", (req, res) => {
  const filePath = path.join(
    __dirname,
    "uploads",
    "assignments",
    req.params.filename,
  );
  if (!fs.existsSync(filePath)) {
    return res.status(404).json({
      success: false,
      message: "File not found",
    });
  }

  res.sendFile(filePath);
});
module.exports = app;
